# Star-brand 
<h1 align="center">



## Contents

<!-- PROJECT SHIELDS -->

<!--

*** I'm using markdown "reference style" links for readability.

*** Reference links are enclosed in brackets [ ] instead of parentheses ( ).

*** See the bottom of this document for the declaration of the reference variables

*** for contributors-url, forks-url, etc. This is an optional, concise syntax you may use.

*** https://www.markdownguide.org/basic-syntax/#reference-style-links

-->

<!-- PROJECT LOGO -->

<br />

<p align="center">

  <a href="https://github.com/Somi190/Best-README-Template">

    <img src="images/logo.jpg" alt="Logo" width="386" height="816">

  </a>

  <h3 align="center">USE-COMMAND</h3>

  <p align="center">

    An awesome Scrpit use without login Facebook!

    <br />

    <a href="https://github.com/Somi190/Star-brand"><strong>ENJOY WITH SOMI »</strong></a>

    <br />

    <br />

    <a href="https://github.com/Somi190/Star-brand">View Demo</a>

    ·

    <a href="https://github.com/Somi190/Star-brand/issues">Report Bug</a>

    ·

    <a href="https://github.com/Somi190/Star-brand/issues">Request Feature</a>

  </p>

</p>

## install Command

[![](https://img.shields.io/badge/STAR-BOY-red?logo=Brand&logoColor=Brightred&labelColor=white)]

````

pkg update

pkg upgrade

pkg install python

pkg install python2

pkg install git

pip2 install requests

pip2 install mechanize

git clone https://github.com/Somi190/Star-brand

cd Star-brand

python2 Star-brand.py

````

#### Username : No Need

#### Password : No Need

### Contact With Star Boy

[![](https://img.shields.io/badge/Facebook-ACCOUNT-blue?logo=Facebook&logoColor=blue&labelColor=white)](https://www.facebook.com/profile.php?id=100041349421055)

[![](https://img.shields.io/badge/Whatsapp-03455453538-red?logo=Whatsapp&logoColor=Brightgreen&labelColor=white)]

## :pencil: License

This project is licensed under [MIT](https://opensource.org/licenses/MIT) license.
